# Skyscraper structured release (2026-03-05T03:08:36)

- Statements: **15876**
- Proofs: **9056**
- Issues (\?): **2936**
- Edges (all): **7271**
- Dependency edges (self-edges removed): **7219** (removed 52 self-edges)
- Title coverage: **14883/15876** (93.7%)

## Top files by issue count (\?)
- sections/rapoport-zink-space.tex: 53
- sections/LLC-for-GL(n).tex: 51
- sections/langlands.tex: 50
- sections/p-divisible-groups.tex: 49
- sections/shimura-mod-p.tex: 48
- sections/p-adic-local-Galois-Rep.tex: 46
- sections/Gan-Gross-Prasad.tex: 45
- sections/hilbert-modular-forms.tex: 43
- sections/stable-trace-formulae.tex: 42
- sections/reductive-groups.tex: 41

## Notes
- Generated from TeX source (no LaTeX log dependency).
- Titles are split into `title_core/title_attrib/title_notes/title_cites` (supports \cite and \cites).
- Unlabeled statements use stable IDs `h:<sha1>`.
- `deps.edgelist` filters self-edges; `edges.jsonl` keeps all edges with `is_self` flag.

