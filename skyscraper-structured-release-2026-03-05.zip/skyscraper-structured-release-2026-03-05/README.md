# Skyscraper structured release

Release date: **2026-03-05**

This package is a structured export of the Skyscraper TeX corpus into machine-readable artifacts.

## Contents
- statements.jsonl  (15876 statements)
- proofs.jsonl      (9056 proofs)
- edges.jsonl       (7271 edges; includes `is_self` flags)
- deps.edgelist     (7219 dependency edges; self-edges removed)
- issues.jsonl      (2936 issue markers from `\?`)
- summary.json      (aggregate statistics)
- release_note.md   (human-readable release notes)
- manifest.json     (metadata + counts)

## JSONL schemas (high level)
### statements.jsonl
- id, env, file, begin_line, end_line
- title_guess, title_core, title_attrib, title_notes, title_cites
- main_label, head_labels, all_labels
- issue_count, has_issue

### proofs.jsonl
- id, file, begin_line, end_line
- refs, refs_count, explicit_target_label, target
- issue_count, has_issue

### edges.jsonl / deps.edgelist
- edges.jsonl: src, dst, file, line, is_self
- deps.edgelist: tab-separated `src<TAB>dst` with self-edges removed

## License
See LICENSE. This release requires contacting the author for authorization.

